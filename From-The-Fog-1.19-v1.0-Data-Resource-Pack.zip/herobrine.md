footsteps \
less frequent sightings \
doors opening themselves \
make door_open utilize /spreadplayers \
redstone torch large tunnel \
change the spawn wandering trader to an illusioner \
torches disappearing \
mossy cobblestone pyramids on land \
add desert pyramids \ 
redstone torch trails on the surface \
blocks breaking around you underground \





sacked:
make herobrine have a rare chance to exist in different worlds
lack of mobs (any)
blocks breaking
sleep sighting
random fires

on hold:
make all herobrine activity go off for a short period of time
make activity increase over time